﻿using Exercise.EF.DAL.Entities;
using Exercise.EF.DAL.Migrations;
using Exercise.EntityFramework.Logic;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Data.SqlClient;
using System.Linq;

namespace Exercise.EntityFramework.Test
{
    [TestClass]
    public class UserServiceTest
    {
        private static TempDatabase _setup;
        private static string _name;
        private static string _connection;

        [ClassInitialize()]
        public static void ClassInit(TestContext context)
        {
            _name = Guid.NewGuid().ToString();

            _setup = new TempDatabase();

            _setup.SetUpDatabase(_name);

            _connection = new SqlConnectionStringBuilder
            {
                DataSource = @"(LocalDB)\MSSQLLocalDB",
                InitialCatalog = _name,
                IntegratedSecurity = true
            }.ConnectionString;
        }

        [ClassCleanup()]
        public static void ClassCleanup()
        {
            _setup.DeleteDatabase(_name);
        }

        private MyContext CreateContext()
        {
            var context = new MyContext(_connection);

            context.Database.BeginTransaction();

            return context;
        }

        [TestMethod]
        public void GetUserByEmail()
        {
            using (var context = CreateContext())
            {
                var userService = new UserService(context);

                User user = userService.GetUserByEmail("test@email.com");

                context.SaveChanges();

                user.UserId.Should().NotBe(0);

                user.Email.Should().Be("test@email.com");
            }
        }

        [TestMethod]
        public void UserShouldNotExist()
        {
            using (var context = CreateContext())
            {
                var userService = new UserService(context);

                User user = userService.GetUserByEmail("test@email.com");

                context.SaveChanges();

                user.UserId.Should().NotBe(0);

                user.Email.Should().Be("test@email.com");
            }

            // since we are using transactions, the users table should be still empty
            using (var context = CreateContext())
            {
                var users = context.Users.ToList();

                users.Should().BeEmpty();
            }
        }
    }
}
